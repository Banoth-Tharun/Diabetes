from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime


db = SQLAlchemy()


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(32), nullable=False, default='patient')  # 'patient' or 'clinician'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    profile = db.relationship('PatientProfile', backref='user', uselist=False)


class PatientProfile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(255))
    age = db.Column(db.Integer)
    sex = db.Column(db.String(16))
    height_cm = db.Column(db.Float)
    weight_kg = db.Column(db.Float)


class GlucoseReading(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    glucose = db.Column(db.Float, nullable=False)
    source = db.Column(db.String(32), default='manual')  # manual, cgm, forecast


class RiskPrediction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    prediction = db.Column(db.Integer, nullable=False)
    probability = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Alert(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    message = db.Column(db.String(512), nullable=False)
    level = db.Column(db.String(16), default='info')  # info, warning, high
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

