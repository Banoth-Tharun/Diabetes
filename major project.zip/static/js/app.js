async function postJson(url, data) {
  const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

function formToJson(form) {
  const data = {};
  new FormData(form).forEach((v, k) => { data[k] = Number(v); });
  return data;
}

const shapCtx = document.getElementById('shapChart');
let shapChart;
const forecastCtx = document.getElementById('forecastChart');
let forecastChart;

async function handlePredict(e) {
  e.preventDefault();
  const payload = formToJson(document.getElementById('predict-form'));
  const pred = await postJson('/api/predict', payload);
  document.getElementById('risk-label').textContent = `Risk: ${pred.prediction} (p=${pred.probability.toFixed(2)})`;
  const exp = await postJson('/api/explain', payload);
  const labels = exp.features;
  const vals = labels.map(f => exp.shap_values[f]);
  if (shapChart) shapChart.destroy();
  shapChart = new Chart(shapCtx, {
    type: 'bar',
    data: { labels, datasets: [{ label: 'SHAP', data: vals, backgroundColor: '#0d6efd' }] },
    options: { responsive: true, scales: { y: { beginAtZero: true } } }
  });
}

async function handleForecast() {
  const res = await postJson('/api/forecast', { readings: [] });
  const pts = res.forecast;
  const labels = pts.map(p => new Date(p.timestamp).toLocaleTimeString());
  const vals = pts.map(p => p.glucose);
  if (forecastChart) forecastChart.destroy();
  forecastChart = new Chart(forecastCtx, {
    type: 'line',
    data: { labels, datasets: [{ label: 'Glucose', data: vals, borderColor: '#198754' }] },
    options: { responsive: true }
  });
}

async function handleUpload() {
  const f = document.getElementById('cgmFile').files[0];
  if (!f) return;
  const form = new FormData();
  form.append('file', f);
  const res = await fetch('/api/forecast', { method: 'POST', body: form });
  const data = await res.json();
  const pts = data.forecast;
  const labels = pts.map(p => new Date(p.timestamp).toLocaleTimeString());
  const vals = pts.map(p => p.glucose);
  if (forecastChart) forecastChart.destroy();
  forecastChart = new Chart(forecastCtx, {
    type: 'line',
    data: { labels, datasets: [{ label: 'Glucose', data: vals, borderColor: '#198754' }] },
    options: { responsive: true }
  });
}

window.addEventListener('DOMContentLoaded', () => {
  const pf = document.getElementById('predict-form');
  if (pf) pf.addEventListener('submit', handlePredict);
  const fb = document.getElementById('forecastBtn');
  if (fb) fb.addEventListener('click', handleForecast);
  const ub = document.getElementById('uploadBtn');
  if (ub) ub.addEventListener('click', handleUpload);
});


